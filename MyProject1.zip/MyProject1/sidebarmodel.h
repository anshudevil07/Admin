#pragma once

#include <QAbstractItemModel>
#include <QHash>
#include <QList>
#include <QString>

class SidebarModel : public QAbstractItemModel
{
    Q_OBJECT

public:
    explicit SidebarModel(QObject *parent = nullptr);
    ~SidebarModel() override;

    QModelIndex index(
        int row,
        int column,
        const QModelIndex &parent = {}
        ) const override;

    QModelIndex parent(
        const QModelIndex &index
        ) const override;

    int rowCount(
        const QModelIndex &parent = {}
        ) const override;

    int columnCount(
        const QModelIndex &parent = {}
        ) const override;

    QVariant data(
        const QModelIndex &index,
        int role = Qt::DisplayRole
        ) const override;

    QHash<int, QByteArray> roleNames() const override;

private:

    struct Item
    {
        QString name;

        Item *parent = nullptr;

        QList<Item*> children;

        ~Item()
        {
            qDeleteAll(children);
        }
    };

    Item *root = nullptr;
};