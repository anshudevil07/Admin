#pragma once

#include <QAbstractTableModel>
#include <QStringList>
#include <QVariantList>

class TableModel : public QAbstractTableModel
{
    Q_OBJECT

    Q_PROPERTY(QString pageTitle
                   READ pageTitle
                       NOTIFY pageChanged)

    Q_PROPERTY(QStringList fieldNames
                   READ fieldNames
                       NOTIFY pageChanged)

public:
    explicit TableModel(QObject *parent = nullptr);

    int rowCount(
        const QModelIndex &parent = {}) const override;

    int columnCount(
        const QModelIndex &parent = {}) const override;

    QVariant data(
        const QModelIndex &index,
        int role = Qt::DisplayRole) const override;

    QVariant headerData(
        int section,
        Qt::Orientation orientation,
        int role = Qt::DisplayRole) const override;

    Q_INVOKABLE void setPage(const QString &page);

    Q_INVOKABLE QVariant valueAt(
        int row,
        int column) const;

    Q_INVOKABLE void addRow(
        const QVariantList &values);

    Q_INVOKABLE void updateRow(
        int row,
        const QVariantList &values);

    Q_INVOKABLE void deleteRow(
        int row);

    QString pageTitle() const;
    QStringList fieldNames() const;

signals:
    void pageChanged();

private:
    QString m_pageTitle;
    QStringList m_headers;
    QStringList m_fieldNames;
    QList<QStringList> m_rows;
};