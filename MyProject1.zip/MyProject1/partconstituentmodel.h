#pragma once

#include <QAbstractTableModel>
#include <QStringList>
#include <QVariantList>

class PartConstituentModel
    : public QAbstractTableModel
{
    Q_OBJECT

public:
    explicit PartConstituentModel(
        QObject *parent = nullptr
        );

    int rowCount(
        const QModelIndex &parent = {}
        ) const override;

    int columnCount(
        const QModelIndex &parent = {}
        ) const override;

    QVariant data(
        const QModelIndex &index,
        int role = Qt::DisplayRole
        ) const override;

    QVariant headerData(
        int section,
        Qt::Orientation orientation,
        int role = Qt::DisplayRole
        ) const override;

    Q_INVOKABLE QVariant valueAt(
        int row,
        int column
        ) const;

    Q_INVOKABLE void addRow(
        const QVariantList &values
        );

    Q_INVOKABLE void updateRow(
        int row,
        const QVariantList &values
        );

    Q_INVOKABLE void deleteRow(
        int row
        );

private:

    QStringList m_headers;

    QList<QStringList> m_rows;
};