import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: root

    property var tableModel

    property bool editMode: false
    property int editingRow: -1

    visible: false

    color: "white"

    border.color: "#d9dee3"

    function openAdd()
    {
        editMode = false
        editingRow = -1

        clearFields()

        visible = true
    }

    function openEdit(row)
    {
        editMode = true
        editingRow = row

        populateFields()

        visible = true
    }

    function close()
    {
        visible = false

        editMode = false
        editingRow = -1
    }

    function clearFields()
    {
        for (var i = 0; i < fields.count; ++i)
            fields.itemAt(i).fieldValue = ""
    }

    function populateFields()
    {
        for (var i = 0; i < fields.count; ++i)
        {
            fields.itemAt(i).fieldValue =
                    root.tableModel.valueAt(
                        editingRow,
                        i
                    )
        }
    }

    function save()
    {
        var values = []

        for (var i = 0; i < fields.count; ++i)
            values.push(
                fields.itemAt(i).fieldValue
            )

        if (editMode)
        {
            root.tableModel.updateRow(
                editingRow,
                values
            )
        }
        else
        {
            root.tableModel.addRow(values)
        }

        close()
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 25

        spacing: 16

        RowLayout {
            Layout.fillWidth: true

            Text {
                Layout.fillWidth: true

                text: root.editMode
                      ? "EDIT PART"
                      : "ADD PART"

                color: "#172536"

                font.pixelSize: 20
                font.bold: true
            }

            Button {
                width: 35
                height: 35

                text: "✕"

                onClicked:
                    root.close()

                background: Rectangle {
                    radius: 4

                    color: parent.down
                           ? "#e5e9ec"
                           : "#f2f4f5"

                    border.color: "#d2d8dd"
                }
            }
        }

        Rectangle {
            Layout.fillWidth: true

            height: 1

            color: "#dfe3e6"
        }

        Flickable {
            Layout.fillWidth: true
            Layout.fillHeight: true

            clip: true

            contentWidth: width
            contentHeight: form.height

            Column {
                id: form

                width: parent.width

                spacing: 15

                Repeater {
                    id: fields

                    model: root.tableModel
                            ? root.tableModel.fieldNames
                            : []

                    delegate: Column {
                        width: form.width

                        spacing: 6

                        property alias fieldValue:
                            input.text

                        Text {
                            text: modelData

                            color: "#34424f"

                            font.pixelSize: 13
                            font.bold: true
                        }

                        TextField {
                            id: input

                            width: parent.width
                            height: 40

                            placeholderText:
                                "Enter " + modelData

                            color: "#172536"

                            font.pixelSize: 13

                            background: Rectangle {
                                radius: 4

                                color: "white"

                                border.color:
                                    input.activeFocus
                                    ? "#172536"
                                    : "#cbd2d8"

                                border.width:
                                    input.activeFocus
                                    ? 2
                                    : 1
                            }
                        }
                    }
                }
            }
        }

        RowLayout {
            Layout.fillWidth: true

            spacing: 10

            Button {
                Layout.fillWidth: true

                height: 42

                text: "CANCEL"

                onClicked:
                    root.close()

                background: Rectangle {
                    radius: 4

                    color: parent.down
                           ? "#e1e5e8"
                           : "#eef1f3"

                    border.color: "#cbd2d8"
                }
            }

            Button {
                Layout.fillWidth: true

                height: 42

                text: root.editMode
                      ? "UPDATE"
                      : "SAVE"

                onClicked:
                    root.save()

                background: Rectangle {
                    radius: 4

                    color: parent.down
                           ? "#0f1a27"
                           : "#172536"
                }

                contentItem: Text {
                    text: parent.text

                    color: "white"

                    horizontalAlignment:
                        Text.AlignHCenter

                    verticalAlignment:
                        Text.AlignVCenter

                    font.bold: true
                }
            }
        }
    }
}