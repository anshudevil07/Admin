import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: root

    property var tableModel

    property bool editMode: false

    property int editingRow: -1

    visible: false

    width: 380

    height: 375

    color: "white"

    radius: 5

    border.color: "#cfd5da"

    border.width: 1


    // =========================================================
    // ADD
    // =========================================================

    function openAdd()
    {
        editMode = false

        editingRow = -1

        clearFields()

        visible = true
    }


    // =========================================================
    // EDIT
    // =========================================================

    function openEdit(row)
    {
        if (!root.tableModel) {
            console.log("ERROR: tableModel is NULL")
            return
        }

        editMode = true
        editingRow = row

        cardField.text =
            String(
                root.tableModel.valueAt(row, 0)
            )

        locationField.text =
            String(
                root.tableModel.valueAt(row, 1)
            )

        boxField.text =
            String(
                root.tableModel.valueAt(row, 2)
            )

        quantityField.text =
            String(
                root.tableModel.valueAt(row, 3)
            )

        makeField.text =
            String(
                root.tableModel.valueAt(row, 4)
            )

        oemField.text =
            String(
                root.tableModel.valueAt(row, 5)
            )

        patternField.text =
            String(
                root.tableModel.valueAt(row, 6)
            )

        versionField.text =
            String(
                root.tableModel.valueAt(row, 7)
            )

        visible = true
    }

    // =========================================================
    // CLEAR
    // =========================================================

    function clearFields()
    {
        cardField.text = ""

        locationField.text = ""

        boxField.text = ""

        quantityField.text = ""

        makeField.text = ""

        oemField.text = ""

        patternField.text = ""

        versionField.text = ""
    }


    // =========================================================
    // CLOSE
    // =========================================================

    function close()
    {
        visible = false

        editMode = false

        editingRow = -1
    }


    // =========================================================
    // SAVE
    // =========================================================

    function save()
    {
        var values = [
            cardField.text,
            locationField.text,
            boxField.text,
            quantityField.text,
            makeField.text,
            oemField.text,
            patternField.text,
            versionField.text
        ]

        console.log(
            "SAVE:",
            editMode ? "UPDATE" : "ADD",
            "ROW:",
            editingRow
        )

        if (editMode && editingRow >= 0) {
            root.tableModel.updateRow(
                editingRow,
                values
            )
        } else {
            root.tableModel.addRow(
                values
            )
        }

        root.close()
    }

    // =========================================================
    // PANEL CONTENT
    // =========================================================

    ColumnLayout {

        anchors.fill: parent

        anchors.margins: 20

        spacing: 8


        // =====================================================
        // HEADER
        // =====================================================

        RowLayout {

            Layout.fillWidth: true

            height: 30


            Text {

                Layout.fillWidth: true

                text: root.editMode
                      ? "EDIT PART"
                      : "ADD PART"

                color: "#172536"

                font.pixelSize: 20

                font.bold: true
            }


            Button {

                width: 30

                height: 30

                text: "✕"


                onClicked: {
                    root.close()
                }


                background: Rectangle {

                    radius: 4

                    color: "grey"

                    border.color: "#cbd2d8"
                }
            }
        }


        // =====================================================
        // LINE
        // =====================================================

        Rectangle {

            Layout.fillWidth: true

            height: 1

            color: "#dfe3e6"
        }


        // =====================================================
        // FIELDS
        // =====================================================

        Flickable {

            Layout.fillWidth: true

            Layout.fillHeight: true

            clip: true

            contentWidth: width

            contentHeight: form.height


            Column {

                id: form

                width: parent.width

                spacing: 6


                // ---------------------------------------------
                // CARD
                // ---------------------------------------------

                RowLayout {

                    width: form.width

                    height: 32

                    spacing: 8


                    Text {

                        Layout.preferredWidth: 85

                        text: "Card"

                        color: "#34424f"

                        font.pixelSize: 12

                        font.bold: true

                        verticalAlignment:
                            Text.AlignVCenter
                    }


                    TextField {

                        id: cardField

                        Layout.fillWidth: true

                        height: 32

                        placeholderText: "Enter Card"
                    }
                }


                // ---------------------------------------------
                // LOCATION
                // ---------------------------------------------

                RowLayout {

                    width: form.width

                    height: 32

                    spacing: 8


                    Text {

                        Layout.preferredWidth: 85

                        text: "Location"

                        color: "#34424f"

                        font.pixelSize: 12

                        font.bold: true

                        verticalAlignment:
                            Text.AlignVCenter
                    }


                    TextField {

                        id: locationField

                        Layout.fillWidth: true

                        height: 32

                        placeholderText: "Enter Location"
                    }
                }


                // ---------------------------------------------
                // BOX
                // ---------------------------------------------

                RowLayout {

                    width: form.width

                    height: 32

                    spacing: 8


                    Text {

                        Layout.preferredWidth: 85

                        text: "Box"

                        color: "#34424f"

                        font.pixelSize: 12

                        font.bold: true

                        verticalAlignment:
                            Text.AlignVCenter
                    }


                    TextField {

                        id: boxField

                        Layout.fillWidth: true

                        height: 32

                        placeholderText: "Enter Box"
                    }
                }


                // ---------------------------------------------
                // QUANTITY
                // ---------------------------------------------

                RowLayout {

                    width: form.width

                    height: 32

                    spacing: 8


                    Text {

                        Layout.preferredWidth: 85

                        text: "Quantity"

                        color: "#34424f"

                        font.pixelSize: 12

                        font.bold: true

                        verticalAlignment:
                            Text.AlignVCenter
                    }


                    TextField {

                        id: quantityField

                        Layout.fillWidth: true

                        height: 32

                        placeholderText: "Enter Quantity"
                    }
                }


                // ---------------------------------------------
                // MAKE
                // ---------------------------------------------

                RowLayout {

                    width: form.width

                    height: 32

                    spacing: 8


                    Text {

                        Layout.preferredWidth: 85

                        text: "Make"

                        color: "#34424f"

                        font.pixelSize: 12

                        font.bold: true

                        verticalAlignment:
                            Text.AlignVCenter
                    }


                    TextField {

                        id: makeField

                        Layout.fillWidth: true

                        height: 32

                        placeholderText: "Enter Make"
                    }
                }


                // ---------------------------------------------
                // OEM
                // ---------------------------------------------

                RowLayout {

                    width: form.width

                    height: 32

                    spacing: 8


                    Text {

                        Layout.preferredWidth: 85

                        text: "OEM"

                        color: "#34424f"

                        font.pixelSize: 12

                        font.bold: true

                        verticalAlignment:
                            Text.AlignVCenter
                    }


                    TextField {

                        id: oemField

                        Layout.fillWidth: true

                        height: 32

                        placeholderText: "Enter OEM"
                    }
                }


                // ---------------------------------------------
                // PATTERN NO
                // ---------------------------------------------

                RowLayout {

                    width: form.width

                    height: 32

                    spacing: 8


                    Text {

                        Layout.preferredWidth: 85

                        text: "Pattern No"

                        color: "#34424f"

                        font.pixelSize: 12

                        font.bold: true

                        verticalAlignment:
                            Text.AlignVCenter
                    }


                    TextField {

                        id: patternField

                        Layout.fillWidth: true

                        height: 32

                        placeholderText: "Enter Pattern No"
                    }
                }


                // ---------------------------------------------
                // VERSION
                // ---------------------------------------------

                RowLayout {

                    width: form.width

                    height: 32

                    spacing: 8


                    Text {

                        Layout.preferredWidth: 85

                        text: "Version"

                        color: "#34424f"

                        font.pixelSize: 12

                        font.bold: true

                        verticalAlignment:
                            Text.AlignVCenter
                    }


                    TextField {

                        id: versionField

                        Layout.fillWidth: true

                        height: 32

                        placeholderText: "Enter Version"
                    }
                }
            }
        }


        // =====================================================
        // BUTTONS
        // =====================================================

        RowLayout {

            Layout.fillWidth: true

            height: 36

            spacing: 8


            Button {

                Layout.fillWidth: true

                height: 36

                text: "CANCEL"


                onClicked: {
                    root.close()
                }


                background: Rectangle {

                    radius: 4

                    color: "grey"

                    border.color: "#cbd2d8"
                }
            }


            Button {

                Layout.fillWidth: true

                height: 36

                text: root.editMode
                      ? "UPDATE"
                      : "SUBMIT"


                onClicked: {
                    root.save()
                }


                background: Rectangle {

                    radius: 4

                    color: "#172536"
                }


                contentItem: Text {

                    text: parent.text

                    color: "white"

                    font.bold: true

                    horizontalAlignment:
                        Text.AlignHCenter

                    verticalAlignment:
                        Text.AlignVCenter
                }
            }
        }
    }
}