import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: root

    width: 310
    color: "#172536"

    property string selectedPage: ""

    signal pageSelected(string page)

    /*
        Find the visible TreeView row for a header name.
    */
    function findHeaderRow(headerName)
    {
        for (var r = 0; r < treeView.rows; r++) {

            if (treeView.depth(r) !== 0)
                continue

            var index = treeView.index(r, 0)

            if (treeView.model.data(
                    index,
                    Qt.DisplayRole
                ) === headerName) {

                return r
            }
        }

        return -1
    }

    /*
        Open the selected header and close
        every other main header.
    */
    function openOnlyHeader(headerName)
    {
        var clickedRow = findHeaderRow(headerName)

        if (clickedRow < 0)
            return

        /*
            If it is already open,
            simply close it.
        */
        if (treeView.isExpanded(clickedRow)) {
            treeView.collapse(clickedRow)
            return
        }

        /*
            Close other top-level headers.

            IMPORTANT:
            Go from bottom to top so that
            collapsing a header above does
            not disturb rows we still need.
        */
        for (var r = treeView.rows - 1; r >= 0; r--) {

            if (treeView.depth(r) !== 0)
                continue

            var currentIndex = treeView.index(r, 0)

            var currentName =
                treeView.model.data(
                    currentIndex,
                    Qt.DisplayRole
                )

            if (currentName !== headerName &&
                treeView.isExpanded(r)) {

                treeView.collapse(r)
            }
        }

        /*
            IMPORTANT:
            After closing other headers,
            the clicked header may have moved
            to another visible row.

            Find it AGAIN.
        */
        clickedRow = findHeaderRow(headerName)

        if (clickedRow >= 0) {
            treeView.expand(clickedRow)
        }
    }

    TreeView {
        id: treeView

        anchors.fill: parent

        model: sidebarModel

        clip: true

        boundsBehavior: Flickable.StopAtBounds

        delegate: Item {

            id: delegateRoot

            required property TreeView treeView
            required property bool isTreeNode
            required property bool expanded
            required property bool hasChildren
            required property int depth

            property string itemName:
                model.display !== undefined
                ? String(model.display)
                : ""

            implicitWidth: treeView.width
            implicitHeight: 44

            /*
                ==============================
                MAIN HEADER
                ==============================
            */
            Rectangle {
                anchors.fill: parent

                visible:
                    delegateRoot.depth === 0

                color:
                    delegateRoot.expanded
                    ? "#22394f"
                    : "#172536"
            }

            /*
                ==============================
                SELECTED SUBHEADER
                ==============================
            */
            Rectangle {
                anchors.fill: parent

                visible:
                    delegateRoot.depth > 0 &&
                    root.selectedPage ===
                    delegateRoot.itemName

                color: "#29435d"
            }

            /*
                ==============================
                CONTENT
                ==============================
            */
            RowLayout {

                anchors.fill: parent

                anchors.leftMargin:
                    delegateRoot.depth === 0
                    ? 18
                    : 42

                anchors.rightMargin: 15

                spacing: 12

                /*
                    + / -
                */
                Rectangle {

                    visible:
                        delegateRoot.depth === 0

                    Layout.preferredWidth: 22
                    Layout.preferredHeight: 22

                    radius: 2

                    color: "#24394e"

                    border.color: "#5b7185"
                    border.width: 1

                    Text {
                        anchors.centerIn: parent

                        color: "#ffffff"

                        font.pixelSize: 15
                        font.bold: true

                        text:
                            delegateRoot.expanded
                            ? "−"
                            : "+"
                    }
                }

                /*
                    Child indentation
                */
                Item {

                    visible:
                        delegateRoot.depth > 0

                    Layout.preferredWidth: 8
                    Layout.preferredHeight: 1
                }

                /*
                    TEXT
                */
                Text {

                    Layout.fillWidth: true

                    text:
                        delegateRoot.itemName

                    color:
                        delegateRoot.depth === 0
                        ? "#ffffff"
                        : "#d8e0e8"

                    font.pixelSize:
                        delegateRoot.depth === 0
                        ? 14
                        : 13

                    font.bold:
                        delegateRoot.depth === 0

                    verticalAlignment:
                        Text.AlignVCenter

                    elide:
                        Text.ElideRight
                }
            }

            /*
                ==============================
                MAIN HEADER CLICK
                ==============================
            */
            MouseArea {

                anchors.fill: parent

                enabled:
                    delegateRoot.depth === 0

                onClicked: {

                    if (delegateRoot.hasChildren) {

                        root.openOnlyHeader(
                            delegateRoot.itemName
                        )
                    }
                }
            }

            /*
                ==============================
                SUBHEADER CLICK
                ==============================
            */
            MouseArea {

                anchors.fill: parent

                enabled:
                    delegateRoot.depth > 0

                onClicked: {

                    root.selectedPage =
                        delegateRoot.itemName

                    root.pageSelected(
                        delegateRoot.itemName
                    )
                }
            }
        }
    }
}