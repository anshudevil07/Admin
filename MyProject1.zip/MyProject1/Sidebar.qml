import QtQuick
import QtQuick.Controls

Item {
    id: root

    property string selectedPage: ""

    signal pageSelected(string page)

    Rectangle {
        anchors.fill: parent

        color: "#172536"

        Column {
            anchors.fill: parent

            Rectangle {
                width: parent.width
                height: 70

                color: "#12202f"

                Text {
                    anchors.centerIn: parent

                    text: "ADMIN PANEL"

                    color: "white"

                    font.pixelSize: 21
                    font.bold: true
                }
            }

            TreeView {
                id: tree

                width: parent.width
                height: parent.height - 70

                model: sidebarModel

                clip: true

                delegate: Item {
                    id: item

                    required property int row
                    required property int depth
                    required property bool expanded
                    required property bool hasChildren
                    required property string display

                    implicitWidth: tree.width
                    implicitHeight: 42

                    Rectangle {
                        anchors.fill: parent

                        color: item.hasChildren
                               ? "#172536"
                               : (root.selectedPage === item.display
                                  ? "#263c52"
                                  : "transparent")
                    }

                    Row {
                        anchors.fill: parent

                        anchors.leftMargin:
                            18 + item.depth * 22

                        spacing: 8

                        Text {
                            width: 18

                            anchors.verticalCenter:
                                parent.verticalCenter

                            text: item.hasChildren
                                  ? (item.expanded
                                     ? "▼"
                                     : "▶")
                                  : ""

                            color: "#d9e1e8"

                            font.pixelSize: 11
                        }

                        Text {
                            anchors.verticalCenter:
                                parent.verticalCenter

                            text: item.display

                            color: "white"

                            font.pixelSize:
                                item.depth === 0 ? 14 : 13

                            font.bold:
                                item.depth === 0
                        }
                    }

                    TapHandler {
                        onTapped: {
                            if (item.hasChildren)
                            {
                                tree.toggleExpanded(item.row)
                            }
                            else
                            {
                                root.pageSelected(
                                    item.display
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}