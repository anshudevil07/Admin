#include "nodenetworkmodel.h"

NodeNetworkModel::NodeNetworkModel(QObject *parent)
    : QAbstractTableModel(parent)
{
    m_headers = {
        "NODE ID",
        "PRIMARY ADDRESS",
        "HOST NAME"
    };

    m_rows = {
        {
            "NODE-001",
            "192.168.1.100",
            "HOST-01"
        },

        {
            "NODE-002",
            "192.168.1.101",
            "HOST-02"
        },

        {
            "NODE-003",
            "10.0.0.25",
            "HOST-03"
        }
    };
}

int NodeNetworkModel::rowCount(
    const QModelIndex &parent
    ) const
{
    if (parent.isValid())
        return 0;

    return m_rows.size();
}

int NodeNetworkModel::columnCount(
    const QModelIndex &parent
    ) const
{
    if (parent.isValid())
        return 0;

    return m_headers.size();
}

QVariant NodeNetworkModel::data(
    const QModelIndex &index,
    int role
    ) const
{
    if (!index.isValid())
        return {};

    if (role != Qt::DisplayRole)
        return {};

    if (index.row() < 0 ||
        index.row() >= m_rows.size())
        return {};

    if (index.column() < 0 ||
        index.column() >= m_headers.size())
        return {};

    return m_rows[index.row()][index.column()];
}

QVariant NodeNetworkModel::headerData(
    int section,
    Qt::Orientation orientation,
    int role
    ) const
{
    if (role != Qt::DisplayRole)
        return {};

    if (orientation == Qt::Horizontal)
        return m_headers.value(section);

    return section + 1;
}

QVariant NodeNetworkModel::valueAt(
    int row,
    int column
    ) const
{
    if (row < 0 ||
        row >= m_rows.size())
        return {};

    if (column < 0 ||
        column >= m_rows[row].size())
        return {};

    return m_rows[row][column];
}

void NodeNetworkModel::addRow(
    const QVariantList &values
    )
{
    int row = m_rows.size();

    beginInsertRows(
        QModelIndex(),
        row,
        row
        );

    QStringList newRow;

    for (const QVariant &value : values)
        newRow.append(value.toString());

    while (newRow.size() < m_headers.size())
        newRow.append("");

    m_rows.append(newRow);

    endInsertRows();
}

void NodeNetworkModel::updateRow(
    int row,
    const QVariantList &values
    )
{
    if (row < 0 ||
        row >= m_rows.size())
        return;

    for (int i = 0;
         i < values.size() &&
         i < m_rows[row].size();
         ++i)
    {
        m_rows[row][i] =
            values[i].toString();
    }

    emit dataChanged(
        index(row, 0),
        index(row, columnCount() - 1)
        );
}

void NodeNetworkModel::deleteRow(
    int row
    )
{
    if (row < 0 ||
        row >= m_rows.size())
        return;

    beginRemoveRows(
        QModelIndex(),
        row,
        row
        );

    m_rows.removeAt(row);

    endRemoveRows();
}