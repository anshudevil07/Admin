import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Window {
    id: root

    width: 1400
    height: 750
    visible: true

    property string selectedPage: "PART TYPE"

    Component.onCompleted: {
        console.log("tableModel =", tableModel)
        console.log("sidebarModel =", sidebarModel)
    }

    RowLayout {
        anchors.fill: parent
        spacing: 0

        // LEFT SIDEBAR
        Sidebar {
            id: sidebar

            Layout.preferredWidth: 340
            Layout.fillHeight: true

            selectedPage: root.selectedPage

            onPageSelected: function(page) {
                root.selectedPage = page
                tableModel.setPage(page)
                editPanel.close()
            }
        }

        // RIGHT SIDE
        Rectangle {
            Layout.fillWidth: true
            Layout.fillHeight: true

            color: "#f4f6f8"

            // PAGE TITLE
            Text {
                anchors.top: parent.top
                anchors.left: parent.left

                anchors.topMargin: 25
                anchors.leftMargin: 30

                text: tableModel
                      ? tableModel.pageTitle
                      : "PART TYPE CONFIGURATION"

                color: "#172536"

                font.pixelSize: 22
                font.bold: true
            }

            // ADD BUTTON
            Button {
                anchors.top: parent.top
                anchors.right: parent.right

                anchors.topMargin: 20
                anchors.rightMargin: 25

                width: 120
                height: 42

                visible: root.selectedPage !== ""

                text: "+  ADD"

                onClicked: {
                    editPanel.openAdd()
                }

                background: Rectangle {
                    radius: 5

                    color: parent.down
                           ? "#0f1a27"
                           : "#172536"
                }

                contentItem: Text {
                    text: parent.text
                    color: "white"

                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter

                    font.bold: true
                }
            }

            // TABLE
            DataTable {
                id: dataTable

                tableModel: tableModel

                anchors.top: parent.top
                anchors.left: parent.left
                anchors.right: editPanel.visible
                               ? editPanel.left
                               : parent.right
                anchors.bottom: parent.bottom

                anchors.topMargin: 80
                anchors.leftMargin: 30
                anchors.rightMargin: 25
                anchors.bottomMargin: 25

                onEditRow: function(row) {
                    editPanel.openEdit(row)
                }

                onDeleteRow: function(row) {
                    tableModel.deleteRow(row)
                }
            }

            // EDIT / ADD PANEL
            EditPanel {
                id: editPanel

                tableModel: tableModel

                width: 380

                anchors.top: parent.top
                anchors.right: parent.right
                anchors.bottom: parent.bottom
            }
        }
    }
}