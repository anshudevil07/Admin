import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Window {
    id: root

    width: 1400
    height: 750

    visible: true

    title: "Admin Panel"

    property string selectedPage: "PART TYPE"

    RowLayout {
        anchors.fill: parent
        spacing: 0

        // =====================================================
        // SIDEBAR
        // =====================================================

        Sidebar {
            id: sidebar

            Layout.preferredWidth: 300
            Layout.fillHeight: true

            selectedPage: root.selectedPage

            onPageSelected: function(page)
            {
                root.selectedPage = page
            }
        }

        // =====================================================
        // CONTENT AREA
        // =====================================================

        Rectangle {
            id: contentArea

            Layout.fillWidth: true
            Layout.fillHeight: true

            color: "#f4f6f8"

            // =================================================
            // PAGE TITLE
            // =================================================

            Text {
                anchors.top: parent.top
                anchors.left: parent.left

                anchors.topMargin: 22
                anchors.leftMargin: 25

                text:
                    root.selectedPage === "PART CONSTITUENT"
                    ? "PART CONSTITUENT"
                    : root.selectedPage === "NODE NETWORK"
                      ? "NODE NETWORK"
                      : root.selectedPage === "DEPLOYMENT"
                        ? "DEPLOYMENT"
                        : "PART TYPE CONFIGURATION"

                color: "#172536"

                font.pixelSize: 22
                font.bold: true
            }

            // =================================================
            // TABLE
            // =================================================

            DataTable {
                id: dataTable

                anchors.top: parent.top
                anchors.left: parent.left
                anchors.bottom: parent.bottom

                anchors.topMargin: 75
                anchors.leftMargin: 25
                anchors.bottomMargin: 25

                anchors.right:
                    editPanel.visible
                    ? editPanel.left
                    : partConstituentEditPanel.visible
                      ? partConstituentEditPanel.left
                      : nodeNetworkEditPanel.visible
                        ? nodeNetworkEditPanel.left
                        : deploymentEditPanel.visible
                          ? deploymentEditPanel.left
                          : parent.right

                anchors.rightMargin:
                    editPanel.visible ||
                    partConstituentEditPanel.visible ||
                    nodeNetworkEditPanel.visible ||
                    deploymentEditPanel.visible
                    ? 12
                    : 25

                tableModel:
                    root.selectedPage === "PART CONSTITUENT"
                    ? partConstituentModel
                    : root.selectedPage === "NODE NETWORK"
                      ? nodeNetworkModel
                      : root.selectedPage === "DEPLOYMENT"
                        ? deploymentModel
                        : partTypeModel

                onEditRequested: function(row) {

                    console.log(
                        "MAIN EDIT:",
                        root.selectedPage,
                        "ROW:",
                        row
                    )

                    if (root.selectedPage === "PART TYPE") {

                        editPanel.openEdit(row)

                    } else if (root.selectedPage === "PART CONSTITUENT") {

                        partConstituentEditPanel.openEdit(row)

                    } else if (root.selectedPage === "NODE NETWORK") {

                        nodeNetworkEditPanel.openEdit(row)

                    } else if (root.selectedPage === "DEPLOYMENT") {

                        deploymentEditPanel.openEdit(row)
                    }
                }

                z: 1
            }

            // =================================================
            // ADD BUTTON
            // =================================================

            Button {
                id: addButton

                anchors.top: parent.top
                anchors.right: parent.right

                anchors.topMargin: 18
                anchors.rightMargin: 25

                width: 125
                height: 40

                z: 10

                visible:
                    root.selectedPage === "PART TYPE"
                    ? !editPanel.visible
                    : root.selectedPage === "PART CONSTITUENT"
                      ? !partConstituentEditPanel.visible
                      : root.selectedPage === "NODE NETWORK"
                        ? !nodeNetworkEditPanel.visible
                        : root.selectedPage === "DEPLOYMENT"
                          ? !deploymentEditPanel.visible
                          : false

                text:
                    root.selectedPage === "NODE NETWORK"
                    ? "+ ADD NODE"
                    : root.selectedPage === "DEPLOYMENT"
                      ? "+ ADD CONF"
                      : "+ ADD PART"

                onClicked: {

                    console.log(
                        "ADD CLICKED:",
                        root.selectedPage
                    )

                    if (root.selectedPage === "PART TYPE") {

                        editPanel.openAdd()

                    } else if (root.selectedPage === "PART CONSTITUENT") {

                        partConstituentEditPanel.openAdd()

                    } else if (root.selectedPage === "NODE NETWORK") {

                        nodeNetworkEditPanel.openAdd()

                    } else if (root.selectedPage === "DEPLOYMENT") {

                        deploymentEditPanel.openAdd()
                    }
                }

                background: Rectangle {

                    radius: 4

                    color:
                        parent.down
                        ? "#0f1a27"
                        : "#172536"
                }

                contentItem: Text {

                    text: parent.text

                    color: "white"

                    font.pixelSize: 13
                    font.bold: true

                    horizontalAlignment:
                        Text.AlignHCenter

                    verticalAlignment:
                        Text.AlignVCenter
                }
            }
            // =================================================
            // PART TYPE PANEL
            // =================================================

            EditPanel {
                id: editPanel

                tableModel: partTypeModel

                width: 380
                height: 450

                anchors.right: parent.right
                anchors.rightMargin: 20

                anchors.top: parent.top
                anchors.topMargin: 75

                z: 20
            }

            // =================================================
            // PART CONSTITUENT PANEL
            // =================================================

            PartConstituentEditPanel {
                id: partConstituentEditPanel

                tableModel: partConstituentModel

                width: 380
                height: 250

                anchors.right: parent.right
                anchors.rightMargin: 20

                anchors.top: parent.top
                anchors.topMargin: 75

                z: 20
            }

            // =================================================
            // NODE NETWORK PANEL
            // =================================================

            NodeNetworkEditPanel {
                id: nodeNetworkEditPanel

                tableModel: nodeNetworkModel

                width: 400
                height: 300

                anchors.right: parent.right
                anchors.rightMargin: 20

                anchors.top: parent.top
                anchors.topMargin: 75

                z: 20
            }
            // =================================================
            // Deplyment Pnnel
            // =================================================

            DeploymentEditPanel {
                id: deploymentEditPanel

                tableModel: deploymentModel

                width: 430
                height: 650

                anchors.right: parent.right
                anchors.rightMargin: 20
                anchors.top: parent.top
                anchors.topMargin: 75

                z: 20
            }
        }
    }
}