#include "deploymentmodel.h"

DeploymentModel::DeploymentModel(QObject *parent)
    : QAbstractTableModel(parent)
{
    m_headers = {
        "APP NAME",
        "SEGMENT",
        "SEG. ID",
        "NODE",
        "NODE ID",
        "ROLE",
        "DISPLAY",
        "SYSTEM",
        "ARGUMENT LIST",
        "FAULT TOLERANCE",
        "INSTANCE",
        "RULE VIOLATION"
    };

    m_rows = {
        {
            "APP-001",
            "SEGMENT-A",
            "SEG-01",
            "NODE-A",
            "NODE-01",
            "PRIMARY",
            "DISPLAY-01",
            "SYS-01",
            "ARG-01",
            "ENABLED",
            "1",
            "0"
        },
        {
            "APP-002",
            "SEGMENT-B",
            "SEG-02",
            "NODE-B",
            "NODE-02",
            "SECONDARY",
            "DISPLAY-02",
            "SYS-02",
            "ARG-02",
            "DISABLED",
            "2",
            "1"
        },
        {
            "APP-003",
            "SEGMENT-C",
            "SEG-03",
            "NODE-C",
            "NODE-03",
            "BACKUP",
            "DISPLAY-03",
            "SYS-03",
            "ARG-03",
            "ENABLED",
            "1",
            "0"
        }
    };
}

int DeploymentModel::rowCount(
    const QModelIndex &parent
    ) const
{
    if (parent.isValid())
        return 0;

    return m_rows.size();
}

int DeploymentModel::columnCount(
    const QModelIndex &parent
    ) const
{
    if (parent.isValid())
        return 0;

    return m_headers.size();
}

QVariant DeploymentModel::data(
    const QModelIndex &index,
    int role
    ) const
{
    if (!index.isValid())
        return {};

    if (role != Qt::DisplayRole)
        return {};

    if (index.row() < 0 ||
        index.row() >= m_rows.size())
        return {};

    if (index.column() < 0 ||
        index.column() >= m_headers.size())
        return {};

    return m_rows[index.row()][index.column()];
}

QVariant DeploymentModel::headerData(
    int section,
    Qt::Orientation orientation,
    int role
    ) const
{
    if (role != Qt::DisplayRole)
        return {};

    if (orientation == Qt::Horizontal)
        return m_headers.value(section);

    return section + 1;
}

QVariant DeploymentModel::valueAt(
    int row,
    int column
    ) const
{
    if (row < 0 ||
        row >= m_rows.size())
        return {};

    if (column < 0 ||
        column >= m_rows[row].size())
        return {};

    return m_rows[row][column];
}

void DeploymentModel::addRow(
    const QVariantList &values
    )
{
    int row = m_rows.size();

    beginInsertRows(
        QModelIndex(),
        row,
        row
        );

    QStringList newRow;

    for (const QVariant &value : values)
        newRow.append(value.toString());

    while (newRow.size() < m_headers.size())
        newRow.append("");

    m_rows.append(newRow);

    endInsertRows();
}

void DeploymentModel::updateRow(
    int row,
    const QVariantList &values
    )
{
    if (row < 0 ||
        row >= m_rows.size())
        return;

    for (int i = 0;
         i < values.size() &&
         i < m_rows[row].size();
         ++i) {

        m_rows[row][i] =
            values[i].toString();
    }

    emit dataChanged(
        index(row, 0),
        index(row, columnCount() - 1)
        );
}

void DeploymentModel::deleteRow(
    int row
    )
{
    if (row < 0 ||
        row >= m_rows.size())
        return;

    beginRemoveRows(
        QModelIndex(),
        row,
        row
        );

    m_rows.removeAt(row);

    endRemoveRows();
}