#include "sidebarmodel.h"

SidebarModel::SidebarModel(QObject *parent)
    : QAbstractItemModel(parent),
    root(new Item)
{
    auto addHeader = [&](const QString &name,
                         const QStringList &children)
    {
        Item *header = new Item{name, root};
        root->children.append(header);

        for (const QString &child : children)
            header->children.append(new Item{child, header});
    };

    addHeader("FILE SYSTEM MANAGEMENT",
              {"CIU-1", "CIU-2", "DDRCU"});

    addHeader("CONFIGURATION",
              {"PART TYPE",
               "PART CONSTITUENT",
               "NODE NETWORK",
               "DEPLOYMENT",
               "SLA CONSTITUENCY"});

    addHeader("MAINTENANCE TEST",
              {"CIU-1", "DMFC", "MSU", "DDRCU"});

    addHeader("LOG MANAGEMENT", {});

    addHeader("INVENTORY MANAGEMENT",
              {"SPARE MANAGEMENT",
               "IP SETTINGS",
               "AUDIO CONFIGURATION"});

    addHeader("NETWORK MANAGEMENT",
              {"DMFC-1", "DMFC-2"});

    addHeader("UTILITY",
              {"MANAGE PASSWORD",
               "CONFIGURE USB FOR LOGIN",
               "FACTORY RESTORE"});
}

SidebarModel::~SidebarModel()
{
    delete root;
}

QModelIndex SidebarModel::index(int row,
                                int column,
                                const QModelIndex &parent) const
{
    if (column != 0)
        return {};

    Item *parentItem = parent.isValid()
                           ? static_cast<Item*>(parent.internalPointer())
                           : root;

    if (row < 0 || row >= parentItem->children.size())
        return {};

    return createIndex(
        row,
        column,
        parentItem->children.at(row)
        );
}

QModelIndex SidebarModel::parent(const QModelIndex &index) const
{
    if (!index.isValid())
        return {};

    Item *item =
        static_cast<Item*>(index.internalPointer());

    Item *parentItem = item->parent;

    if (!parentItem || parentItem == root)
        return {};

    return createIndex(
        parentItem->parent->children.indexOf(parentItem),
        0,
        parentItem
        );
}

int SidebarModel::rowCount(const QModelIndex &parent) const
{
    Item *parentItem = parent.isValid()
    ? static_cast<Item*>(parent.internalPointer())
    : root;

    return parentItem->children.size();
}

int SidebarModel::columnCount(const QModelIndex &) const
{
    return 1;
}

QVariant SidebarModel::data(const QModelIndex &index,
                            int role) const
{
    if (!index.isValid())
        return {};

    Item *item =
        static_cast<Item*>(index.internalPointer());

    if (role == Qt::DisplayRole)
        return item->name;

    return {};
}

QHash<int, QByteArray> SidebarModel::roleNames() const
{
    return {
        {Qt::DisplayRole, "display"}
    };
}