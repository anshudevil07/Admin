import QtQuick
import QtQuick.Controls

Rectangle {
    id: root

    property var tableModel

    property int checkboxWidth: 45
    property int actionWidth: 100
    property int dataRevision: 0
    property var rowIndexes: []

    signal editRequested(int row)

    function rebuildRows()
    {
        var rows = []

        if (root.tableModel) {
            for (var i = 0; i < root.tableModel.rowCount(); ++i)
                rows.push(i)
        }

        root.rowIndexes = rows
    }

    onTableModelChanged: {
        rebuildRows()
    }

    Component.onCompleted: {
        rebuildRows()
    }

    color: "white"

    radius: 5

    border.color: "#d5dbe1"
    border.width: 1

    // =====================================================
    // C++ MODEL CHANGE LISTENERS
    // =====================================================

    Connections {
        target: root.tableModel

        function onDataChanged(topLeft, bottomRight, roles)
        {
            console.log("TABLE DATA CHANGED")
            root.dataRevision++
        }

        function onRowsInserted(parent, first, last)
        {
            root.rebuildRows()
            root.dataRevision++
        }

        function onRowsRemoved(parent, first, last)
        {
            root.rebuildRows()
            root.dataRevision++
        }

        function onModelReset()
        {
            root.rebuildRows()
            root.dataRevision++
        }
    }

    // =====================================================
    // RESPONSIVE COLUMN WIDTH
    // =====================================================

    property real dataColumnWidth:
        root.tableModel &&
        root.tableModel.columnCount() > 0
        ?
            (
                root.width
                - root.checkboxWidth
                - root.actionWidth
            )
            /
            root.tableModel.columnCount()
        : 100

    // =====================================================
    // HEADER
    // =====================================================

    Rectangle {
        id: header

        x: 0
        y: 0

        width: root.width
        height: 45

        color: "#172536"

        Row {
            anchors.fill: parent

            // =============================================
            // CHECKBOX
            // =============================================

            Rectangle {
                width: root.checkboxWidth
                height: 45

                color: "transparent"

                Rectangle {
                    width: 16
                    height: 16

                    anchors.centerIn: parent

                    color: "transparent"

                    border.color: "white"
                    border.width: 1

                    radius: 2
                }
            }

            // =============================================
            // HEADERS
            // =============================================

            Repeater {

                model:
                    root.tableModel
                    ? root.tableModel.columnCount()
                    : 0

                delegate: Rectangle {

                    width:
                        root.dataColumnWidth

                    height: 45

                    color: "transparent"

                    Text {
                        anchors.fill: parent

                        anchors.leftMargin: 6
                        anchors.rightMargin: 6

                        text:
                            root.tableModel
                            ? String(
                                  root.tableModel.headerData(
                                      index,
                                      Qt.Horizontal,
                                      Qt.DisplayRole
                                      )
                                  )
                            : ""

                        color: "white"

                        font.pixelSize: 11
                        font.bold: true

                        verticalAlignment:
                            Text.AlignVCenter

                        horizontalAlignment:
                            Text.AlignLeft

                        elide:
                            Text.ElideRight
                    }
                }
            }

            // =============================================
            // ACTION HEADER
            // =============================================

            Rectangle {

                width: root.actionWidth
                height: 45

                color: "transparent"

                Text {

                    anchors.fill: parent

                    anchors.leftMargin: 6

                    text: "ACTION"

                    color: "white"

                    font.pixelSize: 11
                    font.bold: true

                    verticalAlignment:
                        Text.AlignVCenter
                }
            }
        }
    }

    // =====================================================
    // TABLE BODY
    // =====================================================

    Flickable {
        id: tableFlickable

        x: 0
        y: 45

        width: root.width
        height: Math.max(
                    0,
                    root.height - 45
                    )

        clip: true

        contentWidth: root.width

        contentHeight:
            rowsColumn.height

        boundsBehavior:
            Flickable.StopAtBounds

        Column {
            id: rowsColumn

            width: root.width

            // =================================================
            // THIS IS IMPORTANT
            //
            // modelRevision is deliberately included.
            // When C++ adds/deletes/updates a row,
            // modelRevision changes and this Repeater
            // gets rebuilt.
            // =================================================

            Repeater {

                model: root.rowIndexes


                delegate: Rectangle {

                    id: rowItem

                    property int rowNumber: modelData

                    width:
                        rowsColumn.width

                    height: 48

                    color:
                        index % 2 === 0
                        ? "#ffffff"
                        : "#f7f9fb"

                    border.color:
                        "#e3e7eb"

                    border.width: 1

                    Row {

                        anchors.fill: parent

                        // =====================================
                        // CHECKBOX
                        // =====================================

                        Rectangle {

                            width:
                                root.checkboxWidth

                            height: 48

                            color: "transparent"

                            Rectangle {

                                width: 16
                                height: 16

                                anchors.centerIn:
                                    parent

                                color: "transparent"

                                border.color:
                                    "#65717c"

                                border.width: 1

                                radius: 2
                            }
                        }

                        // =====================================
                        // DATA COLUMNS
                        // =====================================

                        Repeater {

                            model:
                                root.tableModel
                                ?
                                    root.tableModel.columnCount()
                                  :
                                    0

                            delegate: Rectangle {

                                width:
                                    root.dataColumnWidth

                                height: 48

                                color: "transparent"

                                Text {
                                    anchors.fill: parent
                                    anchors.leftMargin: 6
                                    anchors.rightMargin: 6

                                    text: {
                                        var revision = root.dataRevision

                                        return root.tableModel
                                               ? String(
                                                   root.tableModel.valueAt(
                                                       rowItem.rowNumber,
                                                       index
                                                   )
                                                 )
                                               : ""
                                    }

                                    color: "#172536"
                                    font.pixelSize: 11

                                    verticalAlignment:
                                        Text.AlignVCenter

                                    horizontalAlignment:
                                        Text.AlignLeft

                                    elide:
                                        Text.ElideRight
                                }
                            }

                        }

                            // =====================================
                            // ACTION COLUMN
                            // =====================================

                            Rectangle {

                                width:
                                    root.actionWidth

                                height: 48

                                color:
                                    "transparent"

                                Row {

                                    anchors.centerIn:
                                        parent

                                    spacing: 7

                                    // =================================
                                    // EDIT
                                    // =================================

                                    Rectangle {

                                        width: 34
                                        height: 29

                                        radius: 3

                                        color:
                                            "#e8edf2"

                                        Text {

                                            anchors.centerIn:
                                                parent

                                            text: "✎"

                                            color:
                                                "#172536"

                                            font.pixelSize: 16
                                        }

                                        MouseArea {

                                            anchors.fill:
                                                parent

                                            cursorShape:
                                                Qt.PointingHandCursor

                                            onClicked:
                                            {
                                                console.log(
                                                            "EDIT CLICKED, ROW:",
                                                            rowItem.rowNumber
                                                            )

                                                root.editRequested(
                                                            rowItem.rowNumber
                                                            )
                                            }
                                        }
                                    }

                                    // =================================
                                    // DELETE
                                    // =================================

                                    Rectangle {

                                        width: 34
                                        height: 29

                                        radius: 3

                                        color:
                                            "#f1e5e5"

                                        Text {

                                            anchors.centerIn:
                                                parent

                                            text: "X"

                                            color:
                                                "#8b2f2f"

                                            font.pixelSize: 14

                                            font.bold: true
                                        }

                                        MouseArea {

                                            anchors.fill:
                                                parent

                                            cursorShape:
                                                Qt.PointingHandCursor

                                            onClicked:
                                            {
                                                console.log(
                                                            "DELETE CLICKED, ROW:",
                                                            rowItem.rowNumber
                                                            )

                                                if (
                                                        root.tableModel
                                                        ) {

                                                    root.tableModel.deleteRow(
                                                                rowItem.rowNumber
                                                                )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                    }
                }
            }
        }
    }
}