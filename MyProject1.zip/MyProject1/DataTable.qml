import QtQuick
import QtQuick.Controls

Rectangle {
    id: root

    property var tableModel

    signal editRow(int row)
    signal deleteRow(int row)

    color: "white"
    border.color: "#d9dee3"
    border.width: 1

    Column {
        anchors.top: parent.top
        anchors.left: parent.left

        anchors.margins: 10

        // HEADER
        Row {

            Rectangle {
                width: 150
                height: 50
                color: "#172536"

                Text {
                    anchors.centerIn: parent
                    text: "CARD"
                    color: "white"
                    font.bold: true
                }
            }

            Rectangle {
                width: 150
                height: 50
                color: "#172536"

                Text {
                    anchors.centerIn: parent
                    text: "LOCATION"
                    color: "white"
                    font.bold: true
                }
            }

            Rectangle {
                width: 150
                height: 50
                color: "#172536"

                Text {
                    anchors.centerIn: parent
                    text: "BOX"
                    color: "white"
                    font.bold: true
                }
            }

            Rectangle {
                width: 150
                height: 50
                color: "#172536"

                Text {
                    anchors.centerIn: parent
                    text: "QUANTITY"
                    color: "white"
                    font.bold: true
                }
            }

            Rectangle {
                width: 150
                height: 50
                color: "#172536"

                Text {
                    anchors.centerIn: parent
                    text: "MAKE"
                    color: "white"
                    font.bold: true
                }
            }

            Rectangle {
                width: 150
                height: 50
                color: "#172536"

                Text {
                    anchors.centerIn: parent
                    text: "OEM"
                    color: "white"
                    font.bold: true
                }
            }

            Rectangle {
                width: 150
                height: 50
                color: "#172536"

                Text {
                    anchors.centerIn: parent
                    text: "PATTERN NO"
                    color: "white"
                    font.bold: true
                }
            }

            Rectangle {
                width: 150
                height: 50
                color: "#172536"

                Text {
                    anchors.centerIn: parent
                    text: "VERSION"
                    color: "white"
                    font.bold: true
                }
            }

            Rectangle {
                width: 180
                height: 50
                color: "#172536"

                Text {
                    anchors.centerIn: parent
                    text: "ACTION"
                    color: "white"
                    font.bold: true
                }
            }
        }

        // ROW 1
        Row {

            Rectangle {
                width: 150
                height: 50
                border.color: "#d9dee3"

                Text {
                    anchors.centerIn: parent

                    text: root.tableModel.valueAt(0, 0)

                    color: "#172536"
                }
            }

            Rectangle {
                width: 150
                height: 50
                border.color: "#d9dee3"

                Text {
                    anchors.centerIn: parent
                    text: "ABC"
                    color: "#172536"
                }
            }

            Rectangle {
                width: 150
                height: 50
                border.color: "#d9dee3"

                Text {
                    anchors.centerIn: parent
                    text: "ABC"
                    color: "#172536"
                }
            }

            Rectangle {
                width: 150
                height: 50
                border.color: "#d9dee3"

                Text {
                    anchors.centerIn: parent
                    text: "10"
                    color: "#172536"
                }
            }

            Rectangle {
                width: 150
                height: 50
                border.color: "#d9dee3"

                Text {
                    anchors.centerIn: parent
                    text: "ABC"
                    color: "#172536"
                }
            }

            Rectangle {
                width: 150
                height: 50
                border.color: "#d9dee3"

                Text {
                    anchors.centerIn: parent
                    text: "ABC"
                    color: "#172536"
                }
            }

            Rectangle {
                width: 150
                height: 50
                border.color: "#d9dee3"

                Text {
                    anchors.centerIn: parent
                    text: "ABC"
                    color: "#172536"
                }
            }

            Rectangle {
                width: 150
                height: 50
                border.color: "#d9dee3"

                Text {
                    anchors.centerIn: parent
                    text: "1.0"
                    color: "#172536"
                }
            }

            Rectangle {
                width: 180
                height: 50
                border.color: "#d9dee3"

                Row {
                    anchors.centerIn: parent
                    spacing: 5

                    Button {
                        width: 65
                        height: 32
                        text: "Edit"

                        onClicked: root.editRow(0)
                    }

                    Button {
                        width: 65
                        height: 32
                        text: "Delete"

                        onClicked: root.deleteRow(0)
                    }
                }
            }
        }

        // ROW 2
        Row {

            Rectangle {
                width: 150
                height: 50
                border.color: "#d9dee3"

                Text {
                    anchors.centerIn: parent
                    text: "Card XYZ"
                    color: "#172536"
                }
            }

            Rectangle {
                width: 150
                height: 50
                border.color: "#d9dee3"

                Text {
                    anchors.centerIn: parent
                    text: "XYZ"
                    color: "#172536"
                }
            }

            Rectangle {
                width: 150
                height: 50
                border.color: "#d9dee3"

                Text {
                    anchors.centerIn: parent
                    text: "XYZ"
                    color: "#172536"
                }
            }

            Rectangle {
                width: 150
                height: 50
                border.color: "#d9dee3"

                Text {
                    anchors.centerIn: parent
                    text: "20"
                    color: "#172536"
                }
            }

            Rectangle {
                width: 150
                height: 50
                border.color: "#d9dee3"

                Text {
                    anchors.centerIn: parent
                    text: "XYZ"
                    color: "#172536"
                }
            }

            Rectangle {
                width: 150
                height: 50
                border.color: "#d9dee3"

                Text {
                    anchors.centerIn: parent
                    text: "XYZ"
                    color: "#172536"
                }
            }

            Rectangle {
                width: 150
                height: 50
                border.color: "#d9dee3"

                Text {
                    anchors.centerIn: parent
                    text: "XYZ"
                    color: "#172536"
                }
            }

            Rectangle {
                width: 150
                height: 50
                border.color: "#d9dee3"

                Text {
                    anchors.centerIn: parent
                    text: "2.0"
                    color: "#172536"
                }
            }

            Rectangle {
                width: 180
                height: 50
                border.color: "#d9dee3"

                Row {
                    anchors.centerIn: parent
                    spacing: 5

                    Button {
                        width: 65
                        height: 32
                        text: "Edit"

                        onClicked: root.editRow(1)
                    }

                    Button {
                        width: 65
                        height: 32
                        text: "Delete"

                        onClicked: root.deleteRow(1)
                    }
                }
            }
        }
    }
}