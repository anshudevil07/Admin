#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickStyle>

#include "sidebarmodel.h"
#include "parttypemodel.h"
#include "partconstituentmodel.h"
#include "nodenetworkmodel.h"
#include "deploymentmodel.h"

int main(int argc, char *argv[])
{
    QQuickStyle::setStyle("Basic");

    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    // ==========================================
    // C++ MODELS
    // ==========================================

    SidebarModel sidebarModel;

    PartTypeModel partTypeModel;

    PartConstituentModel partConstituentModel;
    NodeNetworkModel nodeNetworkModel;
   DeploymentModel deploymentModel;
    // ==========================================
    // SEND MODELS TO QML
    // ==========================================

    engine.rootContext()->setContextProperty(
        "sidebarModel",
        &sidebarModel
        );

    engine.rootContext()->setContextProperty(
        "partTypeModel",
        &partTypeModel
        );

    engine.rootContext()->setContextProperty(
        "partConstituentModel",
        &partConstituentModel
        );

    engine.rootContext()->setContextProperty(
        "nodeNetworkModel",
        &nodeNetworkModel
        );

    engine.rootContext()->setContextProperty(
        "deploymentModel",
        &deploymentModel
        );
    // ==========================================
    // LOAD MAIN QML
    // ==========================================

    engine.loadFromModule(
        "AdminPanel",
        "Main"
        );

    if (engine.rootObjects().isEmpty())
        return -1;

    return app.exec();
}