#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickStyle>

#include "sidebarmodel.h"
#include "tablemodel.h"

int main(int argc, char *argv[])
{
    QQuickStyle::setStyle("Basic");

    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    SidebarModel sidebarModel;
    TableModel tableModel;

    engine.rootContext()->setContextProperty(
        "sidebarModel",
        &sidebarModel
        );

    engine.rootContext()->setContextProperty(
        "tableModel",
        &tableModel
        );

    engine.loadFromModule(
        "AdminPanel",
        "Main"
        );

    if (engine.rootObjects().isEmpty())
        return -1;

    return app.exec();
}