#include "tablemodel.h"

TableModel::TableModel(QObject *parent)
    : QAbstractTableModel(parent)
{
    setPage("PART TYPE");
}


int TableModel::rowCount(const QModelIndex &parent) const
{
    if (parent.isValid())
        return 0;

    return m_rows.size();
}


int TableModel::columnCount(const QModelIndex &parent) const
{
    if (parent.isValid())
        return 0;

    return m_headers.size();
}


QVariant TableModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid())
        return {};

    if (index.row() < 0 ||
        index.row() >= m_rows.size())
        return {};

    if (index.column() < 0 ||
        index.column() >= m_rows[index.row()].size())
        return {};

    if (role == Qt::DisplayRole)
        return m_rows[index.row()][index.column()];

    return {};
}


QVariant TableModel::headerData(int section,
                                Qt::Orientation orientation,
                                int role) const
{
    if (role != Qt::DisplayRole)
        return {};

    if (orientation == Qt::Horizontal)
        return m_headers.value(section);

    return section + 1;
}


void TableModel::setPage(const QString &page)
{
    beginResetModel();

    if (page == "PART TYPE")
    {
        m_pageTitle = "PART TYPE CONFIGURATION";

        m_headers = {
            "CARD",
            "LOCATION",
            "BOX",
            "QUANTITY",
            "MAKE",
            "OEM",
            "PATTERN NO",
            "VERSION",
            "ACTION"
        };

        m_fieldNames = {
            "Card",
            "Location",
            "Box",
            "Quantity",
            "Make",
            "OEM",
            "Pattern No",
            "Version"
        };

        m_rows = {
            {
                "Card ABC",
                "ABC",
                "ABC",
                "10",
                "ABC",
                "ABC",
                "ABC",
                "1.0",
                ""
            },

            {
                "Card XYZ",
                "XYZ",
                "XYZ",
                "20",
                "XYZ",
                "XYZ",
                "XYZ",
                "2.0",
                ""
            }
        };
    }

    else if (page == "PART CONSTITUENT")
    {
        m_pageTitle = "PART CONSTITUENT";

        m_headers = {
            "PART",
            "CONSTITUENT",
            "QUANTITY",
            "VERSION",
            "ACTION"
        };

        m_fieldNames = {
            "Part",
            "Constituent",
            "Quantity",
            "Version"
        };

        m_rows = {
            {
                "Part A",
                "Constituent A",
                "5",
                "1.0",
                ""
            },

            {
                "Part B",
                "Constituent B",
                "10",
                "2.0",
                ""
            }
        };
    }

    else if (page == "NODE NETWORK")
    {
        m_pageTitle = "NODE NETWORK";

        m_headers = {
            "NODE",
            "IP ADDRESS",
            "PORT",
            "STATUS",
            "ACTION"
        };

        m_fieldNames = {
            "Node",
            "IP Address",
            "Port",
            "Status"
        };

        m_rows = {
            {
                "Node 1",
                "192.168.1.10",
                "8080",
                "Active",
                ""
            },

            {
                "Node 2",
                "192.168.1.11",
                "8081",
                "Inactive",
                ""
            }
        };
    }

    else if (page == "DEPLOYMENT")
    {
        m_pageTitle = "DEPLOYMENT";

        m_headers = {
            "NAME",
            "LOCATION",
            "VERSION",
            "STATUS",
            "ACTION"
        };

        m_fieldNames = {
            "Name",
            "Location",
            "Version",
            "Status"
        };

        m_rows = {
            {
                "System A",
                "Location A",
                "1.0",
                "Active",
                ""
            },

            {
                "System B",
                "Location B",
                "2.0",
                "Inactive",
                ""
            }
        };
    }

    else
    {
        m_pageTitle = page;

        m_headers = {
            "NAME",
            "STATUS",
            "ACTION"
        };

        m_fieldNames = {
            "Name",
            "Status"
        };

        m_rows = {
            {
                "Dummy Data",
                "Active",
                ""
            }
        };
    }

    endResetModel();

    emit pageChanged();
}


QString TableModel::pageTitle() const
{
    return m_pageTitle;
}


QStringList TableModel::fieldNames() const
{
    return m_fieldNames;
}


QVariant TableModel::valueAt(int row, int column) const
{
    if (row < 0 ||
        row >= m_rows.size())
        return {};

    if (column < 0 ||
        column >= m_rows[row].size())
        return {};

    return m_rows[row][column];
}


void TableModel::addRow(const QVariantList &values)
{
    int row = m_rows.size();

    beginInsertRows(
        QModelIndex(),
        row,
        row
        );

    QStringList newRow;

    for (const QVariant &value : values)
        newRow.append(value.toString());

    // ACTION column
    newRow.append("");

    m_rows.append(newRow);

    endInsertRows();
}


void TableModel::updateRow(int row,
                           const QVariantList &values)
{
    if (row < 0 ||
        row >= m_rows.size())
        return;

    for (int i = 0; i < values.size(); ++i)
    {
        if (i < m_rows[row].size() - 1)
            m_rows[row][i] =
                values[i].toString();
    }

    emit dataChanged(
        index(row, 0),
        index(row, columnCount() - 1)
        );
}


void TableModel::deleteRow(int row)
{
    if (row < 0 ||
        row >= m_rows.size())
        return;

    beginRemoveRows(
        QModelIndex(),
        row,
        row
        );

    m_rows.removeAt(row);

    endRemoveRows();
}