import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: root

    property var tableModel
    property bool editMode: false
    property int editingRow: -1

    visible: false

    width: 380
    height: 250

    color: "white"

    radius: 5

    border.color: "#cfd5da"
    border.width: 1

    function openAdd()
    {
        console.log("OPEN ADD PART CONSTITUENT")

        editMode = false
        editingRow = -1

        partIdField.text = ""

        childPartCombo.currentIndex = 0

        visible = true
    }

    function openEdit(row)
    {
        console.log(
            "OPEN EDIT PART CONSTITUENT:",
            row
        )

        if (!root.tableModel) {
            console.log(
                "ERROR: partConstituentModel is NULL"
            )
            return
        }

        editMode = true
        editingRow = row

        /*
            PART ID
        */
        partIdField.text =
            String(
                root.tableModel.valueAt(row, 0)
            )

        /*
            PART CONSTITUENT
        */
        var childPart =
            String(
                root.tableModel.valueAt(row, 2)
            )

        var comboIndex =
            childPartCombo.model.indexOf(
                childPart
            )

        if (comboIndex >= 0)
            childPartCombo.currentIndex = comboIndex
        else
            childPartCombo.currentIndex = 0

        visible = true

        console.log(
            "PART CONSTITUENT PANEL VISIBLE:",
            visible
        )
    }

    function close()
    {
        visible = false

        editMode = false
        editingRow = -1
    }

    function save()
    {
        if (!root.tableModel) {
            console.log(
                "ERROR: tableModel is NULL"
            )
            return
        }

        /*
            Current UI has:
            PART ID
            CHILD PART ID

            The model has:
            PART ID
            PART TYPE
            PART CONSTITUENT

            We keep the existing mapping
            instead of changing your model.
        */
        var values = [
            partIdField.text,
            childPartCombo.currentText,
            childPartCombo.currentText
        ]

        if (editMode) {

            console.log(
                "UPDATE PART CONSTITUENT ROW:",
                editingRow
            )

            root.tableModel.updateRow(
                editingRow,
                values
            )

        } else {

            console.log(
                "ADD PART CONSTITUENT"
            )

            root.tableModel.addRow(
                values
            )
        }

        root.close()
    }

    ColumnLayout {

        anchors.fill: parent

        anchors.margins: 18

        spacing: 12

        /*
            =================================
            TITLE
            =================================
        */

        RowLayout {

            Layout.fillWidth: true

            Text {

                text:
                    editMode
                    ? "EDIT PART CONSTITUENT"
                    : "ADD PART CONSTITUENT"

                color: "#172536"

                font.pixelSize: 17
                font.bold: true

                Layout.fillWidth: true
            }

            Rectangle {

                width: 30
                height: 30

                radius: 3

                color: "#edf1f4"

                Text {

                    anchors.centerIn: parent

                    text: "✕"

                    color: "#172536"

                    font.pixelSize: 17
                }

                MouseArea {

                    anchors.fill: parent

                    onClicked:
                        root.close()
                }
            }
        }

        /*
            =================================
            PART ID
            =================================
        */

        RowLayout {

            Layout.fillWidth: true

            spacing: 10

            Text {

                text: "PART ID"

                color: "#172536"

                font.pixelSize: 12

                Layout.preferredWidth: 110
            }

            TextField {

                id: partIdField

                Layout.fillWidth: true

                height: 34

                placeholderText:
                    "Enter Part ID"
            }
        }

        /*
            =================================
            CHILD PART ID
            =================================
        */

        RowLayout {

            Layout.fillWidth: true

            spacing: 10

            Text {

                text: "CHILD PART ID"

                color: "#172536"

                font.pixelSize: 12

                Layout.preferredWidth: 110
            }

            ComboBox {

                id: childPartCombo

                Layout.fillWidth: true

                height: 34

                model: [
                    "PCB-001",
                    "PCB-002",
                    "PCB-003",
                    "PCB-004"
                ]
            }
        }

        Item {
            Layout.fillHeight: true
        }

        /*
            =================================
            BUTTONS
            =================================
        */

        RowLayout {

            Layout.fillWidth: true

            Layout.alignment:
                Qt.AlignRight

            spacing: 10

            Button {

                text: "CANCEL"

                width: 90
                height: 36

                onClicked:
                    root.close()

                background: Rectangle {

                    radius: 4

                    color:
                        parent.down
                        ? "#d9dee3"
                        : "#edf1f4"

                    border.color: "#cfd5da"
                }

                contentItem: Text {

                    text: parent.text

                    color: "#172536"

                    font.pixelSize: 12
                    font.bold: true

                    horizontalAlignment:
                        Text.AlignHCenter

                    verticalAlignment:
                        Text.AlignVCenter
                }
            }

            Button {

                text:
                    editMode
                    ? "UPDATE"
                    : "DONE"

                width: 90
                height: 36

                onClicked:
                    root.save()

                background: Rectangle {

                    radius: 4

                    color:
                        parent.down
                        ? "#0f1a27"
                        : "#172536"
                }

                contentItem: Text {

                    text: parent.text

                    color: "white"

                    font.pixelSize: 12
                    font.bold: true

                    horizontalAlignment:
                        Text.AlignHCenter

                    verticalAlignment:
                        Text.AlignVCenter
                }
            }
        }
    }
}