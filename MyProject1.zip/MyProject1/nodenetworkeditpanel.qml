import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: root

    property var tableModel
    property bool editMode: false
    property int editingRow: -1

    visible: false

    width: 400
    height: 300

    color: "white"

    radius: 5

    border.color: "#cfd5da"
    border.width: 1

    function openAdd()
    {
        console.log("OPEN ADD NODE")

        editMode = false
        editingRow = -1

        nodeIdField.text = ""

        ip1.text = ""
        ip2.text = ""
        ip3.text = ""
        ip4.text = ""

        hostCombo.currentIndex = 0

        visible = true
    }

    function openEdit(row)
    {
        console.log(
            "OPEN EDIT NODE:",
            row
        )

        if (!root.tableModel) {
            console.log(
                "ERROR: nodeNetworkModel is NULL"
            )
            return
        }

        editMode = true
        editingRow = row

        /*
            NODE ID
        */
        nodeIdField.text =
            String(
                root.tableModel.valueAt(row, 0)
            )

        /*
            PRIMARY ADDRESS
        */
        var address =
            String(
                root.tableModel.valueAt(row, 1)
            )

        var parts =
            address.split(".")

        ip1.text =
            parts.length > 0
            ? parts[0]
            : ""

        ip2.text =
            parts.length > 1
            ? parts[1]
            : ""

        ip3.text =
            parts.length > 2
            ? parts[2]
            : ""

        ip4.text =
            parts.length > 3
            ? parts[3]
            : ""

        /*
            HOST NAME
        */
        var host =
            String(
                root.tableModel.valueAt(row, 2)
            )

        var hostIndex =
            hostCombo.model.indexOf(host)

        if (hostIndex >= 0)
            hostCombo.currentIndex = hostIndex
        else
            hostCombo.currentIndex = 0

        visible = true

        console.log(
            "NODE NETWORK PANEL VISIBLE:",
            visible
        )
    }

    function close()
    {
        visible = false

        editMode = false
        editingRow = -1
    }

    function save()
    {
        if (!root.tableModel) {
            console.log(
                "ERROR: nodeNetworkModel is NULL"
            )
            return
        }

        /*
            Create normal IP address
        */
        var address =
            ip1.text + "." +
            ip2.text + "." +
            ip3.text + "." +
            ip4.text

        var values = [
            nodeIdField.text,
            address,
            hostCombo.currentText
        ]

        if (editMode) {

            console.log(
                "UPDATE NODE ROW:",
                editingRow
            )

            root.tableModel.updateRow(
                editingRow,
                values
            )

        } else {

            console.log(
                "ADD NODE"
            )

            root.tableModel.addRow(
                values
            )
        }

        root.close()
    }

    ColumnLayout {

        anchors.fill: parent

        anchors.margins: 18

        spacing: 12

        /*
            =================================
            TITLE
            =================================
        */

        RowLayout {

            Layout.fillWidth: true

            Text {

                text:
                    editMode
                    ? "EDIT NODE"
                    : "ADD NODE"

                color: "#172536"

                font.pixelSize: 17
                font.bold: true

                Layout.fillWidth: true
            }

            Rectangle {

                width: 30
                height: 30

                radius: 3

                color: "#edf1f4"

                Text {

                    anchors.centerIn: parent

                    text: "✕"

                    color: "#172536"

                    font.pixelSize: 17
                }

                MouseArea {

                    anchors.fill: parent

                    onClicked:
                        root.close()
                }
            }
        }

        /*
            =================================
            NODE ID
            =================================
        */

        RowLayout {

            Layout.fillWidth: true

            spacing: 10

            Text {

                text: "NODE ID"

                color: "#172536"

                font.pixelSize: 12

                Layout.preferredWidth: 120
            }

            TextField {

                id: nodeIdField

                Layout.fillWidth: true

                height: 34

                placeholderText:
                    "Enter Node ID"
            }
        }

        /*
            =================================
            PRIMARY ADDRESS
            =================================
        */

        RowLayout {

            Layout.fillWidth: true

            spacing: 10

            Text {

                text: "PRIMARY ADDRESS"

                color: "#172536"

                font.pixelSize: 12

                Layout.preferredWidth: 120
            }

            RowLayout {

                Layout.fillWidth: true

                spacing: 3

                TextField {
                    id: ip1

                    Layout.fillWidth: true

                    height: 34

                    maximumLength: 3

                    horizontalAlignment:
                        Text.AlignHCenter

                    validator: IntValidator {
                        bottom: 0
                        top: 255
                    }
                }

                Text {
                    text: "."
                    color: "#172536"
                    font.pixelSize: 16
                }

                TextField {
                    id: ip2

                    Layout.fillWidth: true

                    height: 34

                    maximumLength: 3

                    horizontalAlignment:
                        Text.AlignHCenter

                    validator: IntValidator {
                        bottom: 0
                        top: 255
                    }
                }

                Text {
                    text: "."
                    color: "#172536"
                    font.pixelSize: 16
                }

                TextField {
                    id: ip3

                    Layout.fillWidth: true

                    height: 34

                    maximumLength: 3

                    horizontalAlignment:
                        Text.AlignHCenter

                    validator: IntValidator {
                        bottom: 0
                        top: 255
                    }
                }

                Text {
                    text: "."
                    color: "#172536"
                    font.pixelSize: 16
                }

                TextField {
                    id: ip4

                    Layout.fillWidth: true

                    height: 34

                    maximumLength: 3

                    horizontalAlignment:
                        Text.AlignHCenter

                    validator: IntValidator {
                        bottom: 0
                        top: 255
                    }
                }
            }
        }

        /*
            =================================
            HOST NAME
            =================================
        */

        RowLayout {

            Layout.fillWidth: true

            spacing: 10

            Text {

                text: "HOST NAME"

                color: "#172536"

                font.pixelSize: 12

                Layout.preferredWidth: 120
            }

            ComboBox {

                id: hostCombo

                Layout.fillWidth: true

                height: 34

                model: [
                    "HOST-01",
                    "HOST-02",
                    "HOST-03",
                    "HOST-04"
                ]
            }
        }

        Item {
            Layout.fillHeight: true
        }

        /*
            =================================
            BUTTONS
            =================================
        */

        RowLayout {

            Layout.fillWidth: true

            Layout.alignment:
                Qt.AlignRight

            spacing: 10

            Button {

                text: "CANCEL"

                width: 90
                height: 36

                onClicked:
                    root.close()

                background: Rectangle {

                    radius: 4

                    color:
                        parent.down
                        ? "#d9dee3"
                        : "#edf1f4"

                    border.color: "#cfd5da"
                }

                contentItem: Text {

                    text: parent.text

                    color: "#172536"

                    font.pixelSize: 12
                    font.bold: true

                    horizontalAlignment:
                        Text.AlignHCenter

                    verticalAlignment:
                        Text.AlignVCenter
                }
            }

            Button {

                text:
                    editMode
                    ? "UPDATE"
                    : "DONE"

                width: 90
                height: 36

                onClicked:
                    root.save()

                background: Rectangle {

                    radius: 4

                    color:
                        parent.down
                        ? "#0f1a27"
                        : "#172536"
                }

                contentItem: Text {

                    text: parent.text

                    color: "white"

                    font.pixelSize: 12
                    font.bold: true

                    horizontalAlignment:
                        Text.AlignHCenter

                    verticalAlignment:
                        Text.AlignVCenter
                }
            }
        }
    }
}