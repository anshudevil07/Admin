import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: root

    property var tableModel
    property bool editMode: false
    property int editingRow: -1

    visible: false

    width: 430
    height: 520

    color: "white"
    radius: 5

    border.color: "#cfd5da"
    border.width: 1

    function openAdd()
    {
        editMode = false
        editingRow = -1

        applicationNameField.text = ""
        segmentIdField.text = ""
        nodeIdField.text = ""
        argumentField.text = ""
        minDisViolationField.text = ""

        segmentCombo.currentIndex = 0
        nodeTypeCombo.currentIndex = 0
        roleCombo.currentIndex = 0
        displayCombo.currentIndex = 0
        waitsSysTimeCombo.currentIndex = 0
        faultToleranceCombo.currentIndex = 0
        minDistanceCombo.currentIndex = 0
        maxDistanceCombo.currentIndex = 0
        maxDistanceNodeCombo.currentIndex = 0

        visible = true
    }

    function openEdit(row)
    {
        if (!root.tableModel)
            return

        editMode = true
        editingRow = row

        applicationNameField.text =
            String(root.tableModel.valueAt(row, 0))

        var segment =
            String(root.tableModel.valueAt(row, 1))

        var segmentIndex =
            segmentCombo.model.indexOf(segment)

        segmentCombo.currentIndex =
            segmentIndex >= 0 ? segmentIndex : 0

        segmentIdField.text =
            String(root.tableModel.valueAt(row, 2))

        var node =
            String(root.tableModel.valueAt(row, 3))

        var nodeIndex =
            nodeTypeCombo.model.indexOf(node)

        nodeTypeCombo.currentIndex =
            nodeIndex >= 0 ? nodeIndex : 0

        nodeIdField.text =
            String(root.tableModel.valueAt(row, 4))

        var role =
            String(root.tableModel.valueAt(row, 5))

        var roleIndex =
            roleCombo.model.indexOf(role)

        roleCombo.currentIndex =
            roleIndex >= 0 ? roleIndex : 0

        var display =
            String(root.tableModel.valueAt(row, 6))

        var displayIndex =
            displayCombo.model.indexOf(display)

        displayCombo.currentIndex =
            displayIndex >= 0 ? displayIndex : 0

        argumentField.text =
            String(root.tableModel.valueAt(row, 8))

        var fault =
            String(root.tableModel.valueAt(row, 9))

        var faultIndex =
            faultToleranceCombo.model.indexOf(fault)

        faultToleranceCombo.currentIndex =
            faultIndex >= 0 ? faultIndex : 0

        visible = true
    }

    function close()
    {
        visible = false
        editMode = false
        editingRow = -1
    }

    function save()
    {
        if (!root.tableModel)
            return

        var values = [
            applicationNameField.text,
            segmentCombo.currentText,
            segmentIdField.text,
            nodeTypeCombo.currentText,
            nodeIdField.text,
            roleCombo.currentText,
            displayCombo.currentText,
            waitsSysTimeCombo.currentText,
            argumentField.text,
            faultToleranceCombo.currentText,
            minDisViolationField.text,
            minDistanceCombo.currentText
        ]

        if (editMode && editingRow >= 0) {
            root.tableModel.updateRow(
                editingRow,
                values
            )
        } else {
            root.tableModel.addRow(
                values
            )
        }

        root.close()
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 14
        spacing: 7

        Text {
            text: root.editMode
                  ? "EDIT DEPLOYMENT"
                  : "ADD DEPLOYMENT"

            color: "#172536"
            font.pixelSize: 16
            font.bold: true

            Layout.fillWidth: true
        }

        Rectangle {
            Layout.fillWidth: true
            height: 1
            color: "#d9dee3"
        }

        ScrollView {
            Layout.fillWidth: true
            Layout.fillHeight: true

            clip: true

            Column {
                width: parent.width
                spacing: 8

                // APPLICATION NAME
                RowLayout {
                    width: parent.width
                    spacing: 10

                    Text {
                        text: "APPLICATION NAME"
                        Layout.preferredWidth: 145
                        font.pixelSize: 11
                        font.bold: true
                        color: "#4a5560"
                    }

                    TextField {
                        id: applicationNameField
                        Layout.fillWidth: true
                        height: 30
                        font.pixelSize: 12
                        placeholderText: "Application name"
                    }
                }

                // SEGMENT TYPE
                RowLayout {
                    width: parent.width
                    spacing: 10

                    Text {
                        text: "SEGMENT TYPE"
                        Layout.preferredWidth: 145
                        font.pixelSize: 11
                        font.bold: true
                        color: "#4a5560"
                    }

                    ComboBox {
                        id: segmentCombo
                        Layout.fillWidth: true
                        height: 30
                        font.pixelSize: 12

                        model: [
                            "SEGMENT-A",
                            "SEGMENT-B",
                            "SEGMENT-C"
                        ]
                    }
                }

                // SEGMENT ID
                RowLayout {
                    width: parent.width
                    spacing: 10

                    Text {
                        text: "SEGMENT ID"
                        Layout.preferredWidth: 145
                        font.pixelSize: 11
                        font.bold: true
                        color: "#4a5560"
                    }

                    TextField {
                        id: segmentIdField
                        Layout.fillWidth: true
                        height: 30
                        font.pixelSize: 12
                        placeholderText: "Segment ID"
                    }
                }

                // NODE TYPE
                RowLayout {
                    width: parent.width
                    spacing: 10

                    Text {
                        text: "NODE TYPE"
                        Layout.preferredWidth: 145
                        font.pixelSize: 11
                        font.bold: true
                        color: "#4a5560"
                    }

                    ComboBox {
                        id: nodeTypeCombo
                        Layout.fillWidth: true
                        height: 30
                        font.pixelSize: 12

                        model: [
                            "NODE-A",
                            "NODE-B",
                            "NODE-C"
                        ]
                    }
                }

                // NODE ID
                RowLayout {
                    width: parent.width
                    spacing: 10

                    Text {
                        text: "NODE ID"
                        Layout.preferredWidth: 145
                        font.pixelSize: 11
                        font.bold: true
                        color: "#4a5560"
                    }

                    TextField {
                        id: nodeIdField
                        Layout.fillWidth: true
                        height: 30
                        font.pixelSize: 12
                        placeholderText: "Node ID"
                    }
                }

                // ROLE
                RowLayout {
                    width: parent.width
                    spacing: 10

                    Text {
                        text: "ROLE"
                        Layout.preferredWidth: 145
                        font.pixelSize: 11
                        font.bold: true
                        color: "#4a5560"
                    }

                    ComboBox {
                        id: roleCombo
                        Layout.fillWidth: true
                        height: 30
                        font.pixelSize: 12

                        model: [
                            "PRIMARY",
                            "SECONDARY",
                            "BACKUP"
                        ]
                    }
                }

                // DISPLAY
                RowLayout {
                    width: parent.width
                    spacing: 10

                    Text {
                        text: "DISPLAY"
                        Layout.preferredWidth: 145
                        font.pixelSize: 11
                        font.bold: true
                        color: "#4a5560"
                    }

                    ComboBox {
                        id: displayCombo
                        Layout.fillWidth: true
                        height: 30
                        font.pixelSize: 12

                        model: [
                            "DISPLAY-01",
                            "DISPLAY-02",
                            "DISPLAY-03"
                        ]
                    }
                }

                // WAITS FOR SYS TIME
                RowLayout {
                    width: parent.width
                    spacing: 10

                    Text {
                        text: "WAITS FOR SYS TIME"
                        Layout.preferredWidth: 145
                        font.pixelSize: 11
                        font.bold: true
                        color: "#4a5560"
                    }

                    ComboBox {
                        id: waitsSysTimeCombo
                        Layout.fillWidth: true
                        height: 30
                        font.pixelSize: 12

                        model: [
                            "0",
                            "5",
                            "10"
                        ]
                    }
                }

                // LIST OF ARGUMENT
                RowLayout {
                    width: parent.width
                    spacing: 10

                    Text {
                        text: "LIST OF ARGUMENT"
                        Layout.preferredWidth: 145
                        font.pixelSize: 11
                        font.bold: true
                        color: "#4a5560"
                    }

                    TextField {
                        id: argumentField
                        Layout.fillWidth: true
                        height: 30
                        font.pixelSize: 12
                        placeholderText: "Argument list"
                    }
                }

                // FAULT TOLERANCE
                RowLayout {
                    width: parent.width
                    spacing: 10

                    Text {
                        text: "FAULT TOLERANCE"
                        Layout.preferredWidth: 145
                        font.pixelSize: 11
                        font.bold: true
                        color: "#4a5560"
                    }

                    ComboBox {
                        id: faultToleranceCombo
                        Layout.fillWidth: true
                        height: 30
                        font.pixelSize: 12

                        model: [
                            "ENABLED",
                            "DISABLED"
                        ]
                    }
                }

                // MIN DISVIOLATION
                RowLayout {
                    width: parent.width
                    spacing: 10

                    Text {
                        text: "MIN DISVIOLATION"
                        Layout.preferredWidth: 145
                        font.pixelSize: 11
                        font.bold: true
                        color: "#4a5560"
                    }

                    TextField {
                        id: minDisViolationField
                        Layout.fillWidth: true
                        height: 30
                        font.pixelSize: 12
                        placeholderText: "Value"
                    }
                }

                // MIN DISTANCE
                RowLayout {
                    width: parent.width
                    spacing: 10

                    Text {
                        text: "MIN DISTANCE"
                        Layout.preferredWidth: 145
                        font.pixelSize: 11
                        font.bold: true
                        color: "#4a5560"
                    }

                    ComboBox {
                        id: minDistanceCombo
                        Layout.fillWidth: true
                        height: 30
                        font.pixelSize: 12

                        model: [
                            "1",
                            "5",
                            "10"
                        ]
                    }
                }

                // MAX DISTANCE
                RowLayout {
                    width: parent.width
                    spacing: 10

                    Text {
                        text: "MAX DISTANCE"
                        Layout.preferredWidth: 145
                        font.pixelSize: 11
                        font.bold: true
                        color: "#4a5560"
                    }

                    ComboBox {
                        id: maxDistanceCombo
                        Layout.fillWidth: true
                        height: 30
                        font.pixelSize: 12

                        model: [
                            "10",
                            "50",
                            "100"
                        ]
                    }
                }

                // MAX DIST./NODE
                RowLayout {
                    width: parent.width
                    spacing: 10

                    Text {
                        text: "MAX DIST./NODE"
                        Layout.preferredWidth: 145
                        font.pixelSize: 11
                        font.bold: true
                        color: "#4a5560"
                    }

                    ComboBox {
                        id: maxDistanceNodeCombo
                        Layout.fillWidth: true
                        height: 30
                        font.pixelSize: 12

                        model: [
                            "1",
                            "2",
                            "3"
                        ]
                    }
                }
            }
        }

        Rectangle {
            Layout.fillWidth: true
            height: 1
            color: "#d9dee3"
        }

        RowLayout {
            Layout.fillWidth: true
            spacing: 8

            Item {
                Layout.fillWidth: true
            }

            Button {
                text: "CANCEL"
                width: 85
                height: 32

                font.pixelSize: 11

                onClicked: {
                    root.close()
                }
            }

            Button {
                text: root.editMode
                      ? "UPDATE"
                      : "DONE"

                width: 85
                height: 32

                font.pixelSize: 11

                onClicked: {
                    root.save()
                }
            }
        }
    }
}