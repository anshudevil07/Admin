#include "parttypemodel.h"

PartTypeModel::PartTypeModel(
    QObject *parent
    )
    : QAbstractTableModel(parent)
{
    m_headers = {
        "CARD",
        "LOCATION",
        "BOX",
        "QUANTITY",
        "MAKE",
        "OEM",
        "PATTERN NO",
        "VERSION"
    };

    m_rows = {
        {
            "CARD NAME 1",
            "ABC",
            "ABC",
            "10",
            "ABC",
            "ABC",
            "ABC",
            "1.0"
        },

        {
            "CARD NAME 2",
            "XYZ",
            "XYZ",
            "20",
            "XYZ",
            "XYZ",
            "XYZ",
            "2.0"
        },

        {
            "CARD NAME 3",
            "DEF",
            "DEF",
            "15",
            "DEF",
            "DEF",
            "DEF",
            "1.5"
        }
    };
}

int PartTypeModel::rowCount(
    const QModelIndex &parent
    ) const
{
    if (parent.isValid())
        return 0;

    return m_rows.size();
}

int PartTypeModel::columnCount(
    const QModelIndex &parent
    ) const
{
    if (parent.isValid())
        return 0;

    return m_headers.size();
}

QVariant PartTypeModel::data(
    const QModelIndex &index,
    int role
    ) const
{
    if (!index.isValid())
        return {};

    if (role != Qt::DisplayRole)
        return {};

    if (index.row() < 0 ||
        index.row() >= m_rows.size())
    {
        return {};
    }

    if (index.column() < 0 ||
        index.column() >= m_headers.size())
    {
        return {};
    }

    return m_rows[index.row()][index.column()];
}

QVariant PartTypeModel::headerData(
    int section,
    Qt::Orientation orientation,
    int role
    ) const
{
    if (role != Qt::DisplayRole)
        return {};

    if (orientation == Qt::Horizontal)
        return m_headers.value(section);

    return section + 1;
}

QVariant PartTypeModel::valueAt(
    int row,
    int column
    ) const
{
    if (row < 0 ||
        row >= m_rows.size())
    {
        return {};
    }

    if (column < 0 ||
        column >= m_rows[row].size())
    {
        return {};
    }

    return m_rows[row][column];
}

void PartTypeModel::addRow(
    const QVariantList &values
    )
{
    int row = m_rows.size();

    beginInsertRows(
        QModelIndex(),
        row,
        row
        );

    QStringList newRow;

    for (const QVariant &value : values)
        newRow.append(value.toString());

    while (newRow.size() < m_headers.size())
        newRow.append("");

    m_rows.append(newRow);

    endInsertRows();
}

void PartTypeModel::updateRow(
    int row,
    const QVariantList &values
    )
{
    if (row < 0 ||
        row >= m_rows.size())
    {
        return;
    }

    for (
        int i = 0;
        i < values.size() &&
        i < m_rows[row].size();
        ++i
        )
    {
        m_rows[row][i] =
            values[i].toString();
    }

    emit dataChanged(
        index(row, 0),
        index(
            row,
            columnCount() - 1
            )
        );
}

void PartTypeModel::deleteRow(
    int row
    )
{
    if (row < 0 ||
        row >= m_rows.size())
    {
        return;
    }

    beginRemoveRows(
        QModelIndex(),
        row,
        row
        );

    m_rows.removeAt(row);

    endRemoveRows();
}